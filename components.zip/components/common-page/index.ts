export { default } from './common-page';
